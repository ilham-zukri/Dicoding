package com.example.moviecatalogue

import android.content.Intent
import android.content.res.TypedArray
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Looper.prepare
import android.os.ParcelFileDescriptor
import android.widget.AdapterView
import android.widget.ListView

class MainActivity : AppCompatActivity() {

    private val movName = arrayOf(
        "1. Aquaman",
        "2. Avengers : Infinity War",
        "3. Bird Box",
        "4. Bohemian Rhapsody",
        "5. Bumblebee",
        "6. Glass",
        "7. Robin Hood",
        "8. Spiderman : Into Spider-Verse",
        "9. Venom",
        "10. Hunter Killer"
    )

    private val movDesc  = arrayOf(
        "Once home to the most advanced civilization on Earth, Atlantis is now an underwater kingdom ruled by the power-hungry King Orm. With a vast army at his disposal, Orm plans to conquer the remaining oceanic people and then the surface world. Standing in his way is Arthur Curry, Orm's half-human, half-Atlantean brother and true heir to the throne.",
        "As the Avengers and their allies have continued to protect the world from threats too large for any one hero to handle, a new danger has emerged from the cosmic shadows: Thanos. A despot of intergalactic infamy, his goal is to collect all six Infinity Stones, artifacts of unimaginable power, and use them to inflict his twisted will on all of reality. Everything the Avengers have fought for has led up to this moment - the fate of Earth and existence itself has never been more uncertain.",
        "Five years after an ominous unseen presence drives most of society to suicide, a survivor and her two children make a desperate bid to reach safety.",
        "Singer Freddie Mercury, guitarist Brian May, drummer Roger Taylor and bass guitarist John Deacon take the music world by storm when they form the rock 'n' roll band Queen in 1970. Hit songs become instant classics. When Mercury's increasingly wild lifestyle starts to spiral out of control, Queen soon faces its greatest challenge yet – finding a way to keep the band together amid the success and excess.",
        "On the run in the year 1987, Bumblebee finds refuge in a junkyard in a small Californian beach town. Charlie, on the cusp of turning 18 and trying to find her place in the world, discovers Bumblebee, battle-scarred and broken. When Charlie revives him, she quickly learns this is no ordinary yellow VW bug.",
        "In a series of escalating encounters, former security guard David Dunn uses his supernatural abilities to track Kevin Wendell Crumb, a disturbed man who has twenty-four personalities. Meanwhile, the shadowy presence of Elijah Price emerges as an orchestrator who holds secrets critical to both men.",
        "A war-hardened Crusader and his Moorish commander mount an audacious revolt against the corrupt English crown.",
        "Miles Morales is juggling his life between being a high school student and being a spider-man. When Wilson \"Kingpin\" Fisk uses a super collider, others from across the Spider-Verse are transported to this dimension.",
        "Investigative journalist Eddie Brock attempts a comeback following a scandal, but accidentally becomes the host of Venom, a violent, super powerful alien symbiote. Soon, he must rely on his newfound powers to protect the world from a shadowy organization looking for a symbiote of their own.",
        "Captain Glass of the USS Arkansas discovers that a coup d'état is taking place in Russia, so he and his crew join an elite group working on the ground to prevent a war."

    )
    private val movPict = intArrayOf(
        R.drawable.aquaman,
        R.drawable.avenger,
        R.drawable.birdbox,
        R.drawable.bohemian,
        R.drawable.bumblebee,
        R.drawable.glass,
        R.drawable.roibnhood,
        R.drawable.spiderman,
        R.drawable.venom,
        R.drawable.hunter_killer
    )


    private lateinit var dataName: Array<String>
    private lateinit var dataDes: Array<String>
    private lateinit var dataPict: IntArray
    private lateinit var adapter: MovieAdapter
    private var movies = arrayListOf<Movie>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val listView : ListView = findViewById(R.id.lv_list)
        adapter = MovieAdapter(this)
        listView.adapter = adapter

        prepare()
        addItem()

        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->

            val intent = Intent(this@MainActivity, MovieDetail::class.java)
            intent.putExtra(MovieDetail.EXTRA_MOVIE, movies[position])
            startActivity(intent)

        }
    }

    private fun prepare() {
        dataName = movName
        dataDes = movDesc
        dataPict = movPict
    }

    private fun addItem() {
        for (position in dataName.indices){
            val movie = Movie(
                dataName[position],
                dataDes[position],
                dataPict[position]
            )
            movies.add(movie)
        }
        adapter.movies = movies
    }


}
